package com.mycompany.hackatly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
