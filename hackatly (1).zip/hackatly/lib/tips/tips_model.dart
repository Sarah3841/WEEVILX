import '/flutter_flow/flutter_flow_util.dart';
import 'tips_widget.dart' show TipsWidget;
import 'package:flutter/material.dart';

class TipsModel extends FlutterFlowModel<TipsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
